package com.ds.rollingball;

import androidx.annotation.Dimension;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEventListener;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.BounceInterpolator;
import android.widget.Button;
import android.widget.ImageView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor sensor;
    private ImageView img;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        img = (ImageView) findViewById(R.id.imgvw);
    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        //Creating object animatior
        ObjectAnimator obj;
        //Gettig screen width
        int width = Resources.getSystem().getDisplayMetrics().widthPixels;
        //Orientation : 1 = normal. 2 = Landscape
        int orientation = config.orientation;
        switch (config.orientation) {
            case 1:
                obj = ObjectAnimator.ofFloat(img, "X", 0 );
                obj.setDuration(5000);
                obj.setInterpolator(new BounceInterpolator());
                obj.start();
                break;
            case 2:
                obj = ObjectAnimator.ofFloat(img, "X",  (width - img.getWidth()));
                obj.setDuration(5000);
                obj.setInterpolator(new BounceInterpolator());
                obj.start();
                break;
        }
    }

    @Override
    public final void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do something here if sensor accuracy changes.
        //System.out.println("Accuracy");
    }

    @Override
    public final void onSensorChanged(SensorEvent event) {
        // System.out.println("changed");
        // The light sensor returns a single value.
        // Many sensors return 3 values, one for each axis.
        float lux = event.values[0];
        // Do something with this sensor value.

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}